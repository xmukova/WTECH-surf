<?php $__env->startSection('title', 'Shopping cart'); ?>

<!-- napis maui surf -->
<?php
    $showOverlay = true;
?>

<?php $__env->startPush('styles'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/shopping_cart1.css')); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startPush('scripts'); ?>
    <script src="<?php echo e(asset('js/shopping_cart1.js')); ?>"></script>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <div class="cart-heading">
        <p>What's in my bag</p>
        <div class="steps">
            <p class="this-step"><i class="bi bi-1-circle"></i>.<span class="step">step</span></p>
            <p><i class="bi bi-2-circle"></i>.<span class="step">step</span></p>
            <p><i class="bi bi-3-circle"></i>.<span class="step">step</span></p>
        </div>
    </div>

    <div class="bag">
        <div class="products">

            <?php $__currentLoopData = $cartItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                    $product = $item instanceof \App\Models\Product ? $item : $item->product;
                    $productId = $product->id;
                    $quantity = $item->quantity;
                    $size = $item->size;
                    $price = $product->price;
                ?>

                <div class="product">
                    <a href="<?php echo e(route('product_detail', ['id' => $productId])); ?>">
                        <?php if($product->mainImage): ?>
                            <img src="<?php echo e(asset($product->mainImage->image_path)); ?>" alt="<?php echo e($product->name); ?>" class="cart_product darker">
                        <?php elseif($product->images->isNotEmpty()): ?>
                            <img src="<?php echo e(asset($product->images->first()->image_path)); ?>" alt="<?php echo e($product->name); ?>" class="cart_product darker">
                        <?php else: ?>
                            <img src="/images/logo.png" alt="No image" class="cart_product darker">
                        <?php endif; ?>
                    </a>
                    <div class="description">
                        <div class="name-remove">
                            <a href="<?php echo e(route('product_detail', ['id' => $productId])); ?>">
                                <p class="bold name"><?php echo e($product->name); ?></p>
                            </a>
                            <div class="remove-btn">
                                <form method="POST" action="<?php echo e(route('removeFromCart', ['id' => $productId])); ?>">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="btn-close" aria-label="Close"></button>
                                </form>
                                <p>remove</p>
                            </div>
                        </div>
                        <div class="specifications">
                            <form method="POST" action="<?php echo e(route('updateCartItem', ['id' => $productId])); ?>" class="auto-update-form">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('PUT'); ?>

                                <div class="size_quantity">
                                    <div class="size_form">
                                        <?php
                                            $sizes = array_map('trim', explode(',', $product->size));
                                        ?>

                                        <select id="sizes" name="select_size" onchange="this.form.submit()">
                                            <?php $__currentLoopData = $sizes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sizeOption): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($sizeOption); ?>" <?php echo e($size === $sizeOption ? 'selected' : ''); ?>>
                                                    <?php echo e($sizeOption); ?>

                                                </option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>

                                    <div class="number-picker">
                                        <input type="number" name="quantity" value="<?php echo e($quantity); ?>" min="1" max="<?php echo e($product->stock); ?>" onchange="this.form.submit()">
                                    </div>
                                </div>

                                <p class="price"><span class="bold">Price: </span><?php echo e($price); ?> $</p>
                            </form>
                        </div>


                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </div>

        <?php
            $isEmpty = false;
            if (auth()->check()) {
                $isEmpty = $cartItems->isEmpty();
            } else {
                $cart = session('cart', []);
                $isEmpty = empty($cart);
            }
        ?>


        <div class="buttons">
            <div class="final-info">
                <p class="total"><span class="bold2">Total: </span><?php echo e(number_format($total, 2)); ?> $</p>
            </div>
            <a href="<?php echo e(route('products')); ?>"><button class="shop-button">Continue Shopping</button></a>
            <button class="checkout-button"
                <?php if($isEmpty): ?> disabled <?php endif; ?>
                <?php if(auth()->guard()->check()): ?>
                    onclick="window.location.href='<?php echo e(route('shopping_cart2')); ?>'"
                <?php else: ?>
                    onclick="showLoginOverlay()"
                <?php endif; ?>
            >
                Checkout
            </button>
        </div>
    </div>

    <!-- sign in overlay -->
    <div id="login-overlay" class="login-overlay">
        <div class="overlay-content">
            <p>Would you like to sign in?</p>
            <div class="overlay-buttons">
                <a href="<?php echo e(route('login')); ?>" class="overlay-btn">Yes</a>
                <a href="<?php echo e(route('shopping_cart2')); ?>" class="overlay-btn">No</a>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\alemu\OneDrive - Slovenská technická univerzita v Bratislave\Pracovná plocha\4.semester\WTECH\moj-projekt\resources\views/shopping_cart1.blade.php ENDPATH**/ ?>