

<?php $__env->startSection('title', 'Favorites'); ?>

<?php $__env->startPush('styles'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/favorites.css')); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startPush('scripts'); ?>
    <script src="<?php echo e(asset('js/products.js')); ?>"></script>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container my-5">
        <h2 class="text-center mb-4">Your Favorite Products</h2>
        <div class="row g-4">
    </div>

    <div class="store-name text-center overlay-text">
        <a href="<?php echo e(route('homepage')); ?>" aria-label="Homepage">
            Maui Surf
        </a>
    </div>

    <div class="container my-4">
        <div class="row  row-cols-1 row-cols-sm-2 row-cols-md-3 row-cols-lg-4 g-4">
        <?php $__currentLoopData = $favorites; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col">
                <a href="<?php echo e(route('product_detail', ['id' => $product->id])); ?>" class="link_neviditelny" aria-label="Product details">
                    <div class="card darker">
                        <?php if($product->mainImage): ?>
                            <img src="<?php echo e(asset($product->mainImage->image_path)); ?>" alt="<?php echo e($product->name); ?>">
                        <?php endif; ?>
                        <!-- <a href="<?php echo e(route('product_detail', ['id' => $product->id])); ?>" class="link_neviditelny" aria-label="Show details">
                            <img src="<?php echo e(asset('images/products/' . $product->image)); ?>" alt="<?php echo e($product->name); ?>">
                        </a> -->
                        <div class="produkt-ikonky">
                            <form action="<?php echo e(route('favorites.remove', ['product' => $product->id])); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button class="button-ikonka" aria-label="Remove from favorites">
                                    <i class="bi bi-heart-fill"></i>
                                </button>
                            </form>


                            <?php
                                $sizes = array_map('trim', explode(',', $product->size));
                                $defaultSize = count($sizes) > 0 ? $sizes[0] : null;
                                $inCart = false;
                                    if (auth()->check()) {
                                        $inCart = auth()->user()->cartItems->contains(function ($item) use ($product) {
                                            return $item->product_id == $product->id;
                                        });
                                    } else {
                                        $sessionCart = session()->get('cart', []);
                                        foreach ($sessionCart as $item) {
                                            if (isset($item['product_id']) && $item['product_id'] == $product->id) {
                                                $inCart = true;
                                                break;
                                            }
                                        }
                                    }
                            ?>
                            <?php if($inCart): ?> <!-- odstranenie z kosika -->
                                <form method="POST" action="<?php echo e(route('removeFromCart', ['id' => $product->id])); ?>" class="d-inline">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="button-ikonka" aria-label="Remove from cart">
                                        <i class="bi bi-bag-check-fill"></i>
                                    </button>
                                </form>
                            <?php else: ?> <!-- pridanie do kosika -->
                                
                                <form method="POST" action="<?php echo e(route('addToCart', ['id' => $product->id])); ?>" class="d-inline">
                                    <?php echo csrf_field(); ?>
                                    <input type="hidden" name="product_id" value="<?php echo e($product->id); ?>">
                                    <input type="hidden" name="select_size" value="<?php echo e($defaultSize); ?>">
                                    <input type="hidden" name="quantity" value="1">
                                    <button type="submit" class="button-ikonka" aria-label="Add to cart">
                                        <i class="bi bi-bag"></i>
                                    </button>
                                </form>
                            <?php endif; ?>
                        </div>
                        <div class="text-center">
                            <h5 class="text_produkt"><?php echo e($product->name); ?></h5>
                            <p class="text_cena">$<?php echo e(number_format($product->price, 2)); ?></p>
                        </div>
                    </div>
                </a>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/tereziakliestikova/Desktop/predmety/4.semester/WTECH/moj-projekt/resources/views/favorites.blade.php ENDPATH**/ ?>