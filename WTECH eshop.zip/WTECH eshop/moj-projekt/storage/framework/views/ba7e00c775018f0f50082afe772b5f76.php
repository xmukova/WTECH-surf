

<?php $__env->startSection('title', 'Products'); ?>

<?php $__env->startPush('styles'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/products.css')); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startPush('scripts'); ?>
    <script src="<?php echo e(asset('js/products.js')); ?>"></script>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
<div class="store-name text-center overlay-text">
    <a href="<?php echo e(route('homepage')); ?>" aria-label="Homepage">
        Maui Surf
    </a>
</div>

<!-- Navigation + Search Bar-->
<nav class="text-center my-3">

    <form method="GET" action="<?php echo e(url()->current()); ?>" class="search-bar">
        <input type="text" name="search" value="<?php echo e(request('search')); ?>" placeholder=" Search...">
        <button type="submit" class="neviditelny-button"><i class="bi bi-search"></i></button>
    </form>

    <div class="container">
        <div class="row g-1">
            <div class="col-12 col-sm-4">
                <a href="<?php echo e(route('products.byCategory', ['category' => 'surfboards'])); ?>">
                    <button class="button_navbar <?php echo e($currentCategory == 'Surfboards' ? 'active_button' : ''); ?>">SURFBOARDS</button>
                </a>
            </div>
            <div class="col-12 col-sm-4">
                <a href="<?php echo e(route('products.byCategory', ['category' => 'equipment'])); ?>">
                    <button class="button_navbar <?php echo e($currentCategory == 'Equipment' ? 'active_button' : ''); ?>">EQUIPMENT</button>
                </a>
            </div>
            <div class="col-12 col-sm-4">
                <a href="<?php echo e(route('products.byCategory', ['category' => 'accessories'])); ?>">
                    <button class="button_navbar <?php echo e($currentCategory == 'Accessories' ? 'active_button' : ''); ?>">ACCESSORIES</button>
                </a>
            </div>
        </div>

        <div class="row justify-content-between">
            <div class="col-auto ">  <!--filter button-->
                <button id = "filter_start" class="button_navbar_2 "><i class="bi bi-filter"></i> Filter</button>
            </div>
            <div class="col-auto"> <!-- dropdown menu - zoradenie -->
                <div class="dropdown">
                    <button class="button_navbar_2  dropdown-toggle" type="button" data-bs-toggle="dropdown" aria-expanded="false">
                        Sort by
                    </button>
                    <ul class="dropdown-menu">
                        <li><a class="dropdown-item" href="<?php echo e(request()->fullUrlWithQuery(['sort' => 'price_asc'])); ?>">Price: Low to High</a></li>
                        <li><a class="dropdown-item" href="<?php echo e(request()->fullUrlWithQuery(['sort' => 'price_desc'])); ?>">Price: High to Low</a></li>
                        <li><a class="dropdown-item" href="<?php echo e(request()->fullUrlWithQuery(['sort' => 'az'])); ?>">A - Z</a></li>
                        <li><a class="dropdown-item" href="<?php echo e(request()->fullUrlWithQuery(['sort' => 'za'])); ?>">Z - A</a></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    <!-- FILTER MENU -->
    <aside id="filter-menu" class="filter-sidebar">
            <div class="filter-header">
                <h5>FILTERS</h5>
                <button id = "close_filter"class="close-btn" aria-label="Close filter"><i class="bi bi-x"></i></button>
            </div>
        <form method="GET" action="<?php echo e(url()->current()); ?>">    
            <!-- Reset filter  -->
            <a href="<?php echo e(url()->current()); ?>" class="reset_filter">Reset Filters</a>

            <!-- filters -->
            <div class="filter-section">
                <label class="price_filter">PRICE RANGE</label>
                <div class="price-range">
                    <span id="min-price">$ <?php echo e(request('min_price', 0)); ?></span>
                    
                    <span id="max-price">$ <?php echo e(request('max_price', 2000)); ?></span>
                </div>
                <div class="slider-container">
                    <div class="slider-track"></div>
                    <input type="range" name="min_price" id="slider-1" class="range-slider" min="0" max="2000" step="1" value="<?php echo e(request('min_price', 0)); ?>">
                    <input type="range" name="max_price" id="slider-2" class="range-slider" min="0" max="2000" step="1" value="<?php echo e(request('max_price', 2000)); ?>">
                </div>
            </div>
            <div class="filter-section">
                <ul class = "category_filter"> SUBCATEGORY
                    <?php $__currentLoopData = $subcategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subcategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li>
                            <input type="checkbox" name="subcategory[]" value="<?php echo e($subcategory->id); ?>" id="sub-<?php echo e($subcategory->id); ?>"
                                <?php echo e(in_array($subcategory->id, request()->input('subcategory', [])) ? 'checked' : ''); ?>>
                            <label for="sub-<?php echo e($subcategory->id); ?>"><?php echo e($subcategory->name); ?></label>
                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>    
                <ul class = "category_filter"> COLOR
                    <li><input type="checkbox" name="color[]" value="red" id="red"  <?php echo e(in_array('red', request()->input('color', [])) ? 'checked' : ''); ?>><label for="red" >Red</label></li>
                    <li><input type="checkbox" name="color[]" value="green" id="green"  <?php echo e(in_array('green', request()->input('color', [])) ? 'checked' : ''); ?>><label for="green">Green</label></li>
                    <li><input type="checkbox" name="color[]" value="blue" id="blue"  <?php echo e(in_array('blue', request()->input('color', [])) ? 'checked' : ''); ?>><label for="blue">Blue</label></li>
                    <li><input type="checkbox" name="color[]" value="yellow" id="yellow"  <?php echo e(in_array('yellow', request()->input('color', [])) ? 'checked' : ''); ?>><label for="yellow">Yellow</label></li>
                    <li><input type="checkbox" name="color[]" value="white" id="white"  <?php echo e(in_array('white', request()->input('color', [])) ? 'checked' : ''); ?>><label for="white">White</label></li>
                    <li><input type="checkbox" name="color[]" value="black" id="black"  <?php echo e(in_array('black', request()->input('color', [])) ? 'checked' : ''); ?>><label for="black">Black</label></li>
                    <li><input type="checkbox" name="color[]" value="other" id="others"  <?php echo e(in_array('others', request()->input('color', [])) ? 'checked' : ''); ?>><label for="others">Others</label></li>
                </ul>
                <ul class = "category_filter">SIZE
                    <li><input type="checkbox" name="size[]" value="XS" id="sizeXS" <?php echo e(in_array('XS', request()->input('size', [])) ? 'checked' : ''); ?>><label for="sizeS">XS</label></li>
                    <li><input type="checkbox" name="size[]" value="S" id="sizeS" <?php echo e(in_array('S', request()->input('size', [])) ? 'checked' : ''); ?>><label for="sizeS">S</label></li>
                    <li><input type="checkbox" name="size[]" value="M" id="sizeM" <?php echo e(in_array('M', request()->input('size', [])) ? 'checked' : ''); ?>><label for="sizeM">M</label></li>
                    <li><input type="checkbox" name="size[]" value="L" id="sizeL" <?php echo e(in_array('L', request()->input('size', [])) ? 'checked' : ''); ?>><label for="sizeL">L</label></li>
                    <li><input type="checkbox" name="size[]" value="XL" id="sizeXL" <?php echo e(in_array('XL', request()->input('size', [])) ? 'checked' : ''); ?>><label for="sizeL">XL</label></li>
                </ul>
            </div>
            <button class="koniec_filter" type="submit">Apply Filters</button>
        </form>
    </aside>
    <div id = "efekt" class = "overlay"></div>    
    
</nav> 
<div class="background_section"></div>

<!-- PRODUCTS SECTION -->
<div class="container my-4">
    <div class="row  row-cols-1 row-cols-sm-2 row-cols-md-3 row-cols-lg-4 g-4">
        <!-- Product Card -->
        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col">
                <a href="<?php echo e(route('product_detail', ['id' => $product->id])); ?>" class="link_neviditelny" aria-label="Product details">
                    <div class="card darker">
                        <?php
                            $imagePath = $product->mainImage->image_path ?? $product->images->first()->image_path;
                        ?>
                        <div class="product-image-wrapper">
                            <img src="<?php echo e(asset($imagePath)); ?>" alt="<?php echo e($product->name); ?>" class="product-image">
                        </div>
                        <div class="produkt-ikonky">
                            <?php if(!auth()->check() || !auth()->user()->is_admin): ?>
                                <?php if(auth()->check()): ?>
                                    <?php
                                        $isFavorite = auth()->user()->favorites->contains($product->id);
                                    ?> 
                                    <form action="<?php echo e($isFavorite ? route('favorites.remove', $product->id) : route('favorites.add', $product->id)); ?>" method="POST" class="d-inline">
                                        <?php echo csrf_field(); ?>
                                        <?php if($isFavorite): ?>
                                            <?php echo method_field('DELETE'); ?>
                                        <?php endif; ?>
                                        <button type="submit" class="button-ikonka" aria-label="<?php echo e($isFavorite ? 'Remove from favorites' : 'Add to favorites'); ?>">
                                            <i class="bi <?php echo e($isFavorite ? 'bi-heart-fill' : 'bi-heart'); ?>"></i>
                                        </button>
                                    </form>
                                <?php else: ?>
                                    <button class="button-ikonka" aria-label="First log in to favorite" onclick="event.preventDefault(); showLoginOverlay()">
                                        <i class="bi bi-heart"></i>
                                    </button>
                                <?php endif; ?>

                                <?php
                                    $sizes = array_map('trim', explode(',', $product->size));
                                    $defaultSize = count($sizes) > 0 ? $sizes[0] : null;
                                    $inCart = false;
                                        if (auth()->check()) {
                                            $inCart = auth()->user()->cartItems->contains(function ($item) use ($product) {
                                                return $item->product_id == $product->id;
                                            });
                                        } else {
                                            $sessionCart = session()->get('cart', []);
                                            foreach ($sessionCart as $item) {
                                                if (isset($item['product_id']) && $item['product_id'] == $product->id) {
                                                    $inCart = true;
                                                    break;
                                                }
                                            }
                                        }
                                ?>
                                <?php if($inCart): ?> <!-- odstranenie z kosika -->
                                    <form method="POST" action="<?php echo e(route('removeFromCart', ['id' => $product->id])); ?>" class="d-inline">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="submit" class="button-ikonka" aria-label="Remove from cart">
                                            <i class="bi bi-bag-check-fill"></i>
                                        </button>
                                    </form>
                                <?php else: ?> <!-- pridanie do kosika -->
                                    <form method="POST" action="<?php echo e(route('addToCart', ['id' => $product->id])); ?>" class="d-inline">
                                        <?php echo csrf_field(); ?>
                                        <input type="hidden" name="product_id" value="<?php echo e($product->id); ?>">
                                        <input type="hidden" name="select_size" value="<?php echo e($defaultSize); ?>">
                                        <input type="hidden" name="quantity" value="1">
                                        <button type="submit" class="button-ikonka" aria-label="Add to cart">
                                            <i class="bi bi-bag"></i>
                                        </button>
                                    </form>
                                <?php endif; ?>
                            <?php endif; ?>
                        </div>
                        <div class="card-body text-center">
                            <h5 class="card-title text_produkt"><?php echo e($product->name); ?></h5>
                            <p class="card-text text_cena">$<?php echo e(number_format($product->price, 2)); ?></p>
                        </div>
                    </div>
                </a>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </div>
</div>

<!-- ciselnik stranok -->
<div class="strankovanie">
    <!-- sipka vlavo -->
    <?php if($products->onFirstPage()): ?>
        <button class="strankovanie_sipka" aria-label="Pages left" disabled><i class="bi bi-chevron-left"></i></button>
    <?php else: ?>
        <a href="<?php echo e(request()->fullUrlWithQuery(['page' => $products->currentPage() - 1])); ?>" class="strankovanie_sipka">
            <i class="bi bi-chevron-left"></i>
        </a>
    <?php endif; ?>
    <!-- cisla -->
    <?php for($i = 1; $i <= $products->lastPage(); $i++): ?>
        <a href="<?php echo e(request()->fullUrlWithQuery(['page' => $i])); ?>" class="stranka <?php echo e($products->currentPage() == $i ? 'active' : ''); ?>">
            <?php echo e($i); ?>

        </a>
    <?php endfor; ?>
    <!-- sipka vpravo -->
    <?php if($products->hasMorePages()): ?>
        <a href="<?php echo e(request()->fullUrlWithQuery(['page' => $products->currentPage() + 1])); ?>" class="strankovanie_sipka"><i class="bi bi-chevron-right"></i></a>
    <?php else: ?>
        <button class="strankovanie_sipka" aria-label="Pages right" disabled><i class="bi bi-chevron-right"></i></button>
    <?php endif; ?>
</div>


<!-- overlay pre prihlasenie -->
<div id="login-overlay" class="login-overlay" style="display: none;">
    <div class="overlay-content">
        <p>You must first log in to add favorites. Would you like to log/sign in?</p>
        <div class="overlay-buttons">
            <a href="<?php echo e(route('login')); ?>" class="overlay-btn">Yes</a>
            <button class="overlay-btn" onclick="closeOverlay()">No</button>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\alemu\OneDrive - Slovenská technická univerzita v Bratislave\Pracovná plocha\4.semester\WTECH\moj-projekt\resources\views/products.blade.php ENDPATH**/ ?>