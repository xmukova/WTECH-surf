<!-- Footer -->
<footer class="footer container-fluid">
    <div class = "row text-center">
        <div class="col-md-4 col-12">
            <p class="footer_heading">CONTACT</p>
            <div class="footer-info">
                <p>Email: example@email.com<br>Phone: +123 456 789<br>Address: 123 Street, City, Country</p>
            </div>
        </div>
        <div class="col-md-4 col-12">
            <p class="footer_heading">CUSTOMER SERVICE</p>
            <div class="footer-info">
                <p>Return & Delivery<br>Reviews<br>About us</p>
            </div>
        </div>
        <div class="col-md-4 col-12">
            <div class="footer-info">
                <p>Share your experience with your friends on socials</p>
                <i class="bi bi-facebook share"></i>
                <i class="bi bi-instagram share"></i>
                <i class="bi bi-linkedin share"></i>
                <i class="bi bi-twitter-x share"></i>
            </div>
        </div>
    </div>
</footer><?php /**PATH C:\Users\alemu\OneDrive - Slovenská technická univerzita v Bratislave\Pracovná plocha\4.semester\WTECH\moj-projekt\resources\views/parts/footer.blade.php ENDPATH**/ ?>