<!-- Footer -->
<footer class="footer container-fluid">
    <div class = "row text-center">
        <div class="col-md-4 col-12">
            <p class="footer_heading">CONTACT</p>
            <div class="footer-info">
                <p>Email: example@email.com<br>Phone: +123 456 789<br>Address: 123 Street, City, Country</p>
            </div>
        </div>
        <div class="col-md-4 col-12">
            <p class="footer_heading">CUSTOMER SERVICE</p>
            <div class="footer-info">
                <p>Return & Delivery<br>Reviews<br>About us</p>
            </div>
        </div>
        <div class="col-md-4 col-12">
            <div class="footer-info">
                <p>Share your experience with your friends on socials</p>
                <i class="bi bi-facebook share"></i>
                <i class="bi bi-instagram share"></i>
                <i class="bi bi-linkedin share"></i>
                <i class="bi bi-twitter-x share"></i>
            </div>
        </div>
    </div>
</footer>